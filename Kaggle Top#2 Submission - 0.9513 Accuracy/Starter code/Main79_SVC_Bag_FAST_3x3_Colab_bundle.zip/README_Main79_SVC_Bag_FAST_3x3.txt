MAIN79 SVC-BAG FAST 3x3 — COLAB RUN INSTRUCTIONS

1. Open Google Colab.
2. Upload Main79_SVC_Bag_FAST_3x3_Colab_RunAll.ipynb.
3. Upload Main79_SVC_Bag_FAST_3x3_Colab_bundle.zip through the Colab Files sidebar.
4. Open the notebook and Run All once.
5. The first cell extracts/verifies the required files from the ZIP.

Required files inside the ZIP:
- train.json
- test.json
- main66.py
- main79_95_kaggle.py
- main64_oof_meta_features.npy
- main64_val_meta_features.npy
- main64_oof_svm.npy
- main64_oof_nbsvm.npy
- main64_oof_hgb.npy
- main64_oof_local.npy

Experiment:
- 3 LinearSVC bag members: seeds 42, 123, 777
- 3 strict OOF folds = 9 SVC OOF fits
- Original SVC C = 10
- Teacher META_C = 3.0
- Main79 residual architecture is the exact supplied architecture
- Main79 residual seeds = 42, 123, 777
- Existing Exp11 branch is reproduced after the new Main79 validation
- Existing locked references are 93.6433% Main79 and 93.8805% Main79+Exp11

Why 3x3:
The previous 10x5 version took about 1.5 hours and the runtime disconnected before Main79 training. This version keeps the OOF protocol leakage-safe while reducing the SVC count from 50 to 9.

Outputs:
/content/main79_svcbag_fast_outputs/

Final package:
/content/main79_svcbag_fast_outputs.zip

After completion, send back main79_svcbag_fast_outputs.zip for analysis.
